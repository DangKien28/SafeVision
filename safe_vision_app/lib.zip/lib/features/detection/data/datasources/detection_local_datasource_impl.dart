import 'dart:isolate';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tflite_flutter/tflite_flutter.dart';
import 'detection_local_datasource.dart';
import '../../../../core/constants/app_constants.dart';
import '../../../../core/constants/asset_paths.dart';
import '../../../../core/error/exceptions.dart';
import '../../../../core/utils/ai_helper.dart';
import '../../../../core/utils/image_converter.dart';

class DetectionLocalDatasourceImpl implements DetectionLocalDatasource {
  Interpreter? _interpreter;
  List<String> _labels = [];
  bool _modelLoaded = false;
  bool _isRunning = false;

  // Persistent isolate — spawn 1 lần, tái dùng mãi
  Isolate? _isolate;
  SendPort? _isolateSendPort;
  ReceivePort? _mainReceivePort;

  // ── Load model ────────────────────────────────────────────

  @override
  Future<void> loadModel() async {
    try {
      final labelsData = await rootBundle.loadString(AssetPaths.labels);
      _labels = labelsData
          .split('\n')
          .map((l) => l.trim())
          .where((l) => l.isNotEmpty)
          .toList();

      final options = InterpreterOptions()..threads = 2;
      _interpreter =
          await Interpreter.fromAsset(AssetPaths.modelFile, options: options);

      // ── THÊM 3 DÒNG NÀY ──────────────────────────────────
      debugPrint(
          ' MODEL OK | labels=${_labels.length} | input=${_interpreter!.getInputTensor(0).shape} | output=${_interpreter!.getOutputTensor(0).shape}');
      // ─────────────────────────────────────────────────────

      _modelLoaded = true;
      await _spawnIsolate();
      debugPrint(' ISOLATE SPAWNED');
    } catch (e) {
      debugPrint(' MODEL LOAD FAILED: $e');
      throw ModelNotFoundException('Không thể tải model: $e');
    }
  }

  // ── Spawn isolate 1 lần duy nhất ─────────────────────────

  Future<void> _spawnIsolate() async {
    _mainReceivePort = ReceivePort();

    _isolate = await Isolate.spawn(
      _persistentIsolateEntry,
      _mainReceivePort!.sendPort,
    );

    // Nhận SendPort từ isolate để gửi job về sau
    _isolateSendPort = await _mainReceivePort!.first as SendPort;
  } 

  // ── Inference ─────────────────────────────────────────────

  @override
  Future<List<Map<String, dynamic>>> runInference(CameraImage image) async {
    if (!_modelLoaded || _interpreter == null || _isolateSendPort == null) {
      return [];
    }
    if (_isRunning) return []; // Bỏ qua nếu frame trước chưa xong

    _isRunning = true;
    try {
      // Copy bytes NGAY để giải phóng camera buffer
      final planeBytes =
          image.planes.map((p) => Uint8List.fromList(p.bytes)).toList();
      final rowStrides = image.planes.map((p) => p.bytesPerRow).toList();
      final pixelStrides =
          image.planes.map((p) => p.bytesPerPixel ?? 1).toList();

      // Mở port nhận kết quả cho job này
      final replyPort = ReceivePort();

      // Gửi job sang isolate đang chờ
      _isolateSendPort!.send(_InferenceJob(
        replyPort: replyPort.sendPort,
        planeBytes: planeBytes,
        planeRowStrides: rowStrides,
        planePixelStrides: pixelStrides,
        imageWidth: image.width,
        imageHeight: image.height,
        interpreterAddress: _interpreter!.address,
        labels: List.unmodifiable(_labels),
        inputSize: AppConstants.inputSize,
        confidenceThreshold: AppConstants.confidenceThreshold,
        iouThreshold: AppConstants.iouThreshold,
        maxDetections: AppConstants.maxDetections,
      ));

      final result = await replyPort.first;
      replyPort.close();

      if (result is String) throw InferenceException(result);
      return List<Map<String, dynamic>>.from(result as List);
    } catch (e) {
      if (e is ModelNotFoundException) rethrow;
      throw InferenceException('Lỗi inference: $e');
    } finally {
      _isRunning = false;
    }
  }

  // ── Close ─────────────────────────────────────────────────

  @override
  Future<void> closeModel() async {
    _isolate?.kill(priority: Isolate.immediate);
    _isolate = null;
    _mainReceivePort?.close();
    _mainReceivePort = null;
    _isolateSendPort = null;

    _interpreter?.close();
    _interpreter = null;
    _modelLoaded = false;
    _isRunning = false;
  }
}

// ── Persistent isolate entry — chạy vòng lặp chờ job ──────────────────────

void _persistentIsolateEntry(SendPort mainSendPort) {
  final jobPort = ReceivePort();

  // Gửi SendPort của mình về main isolate để nhận job
  mainSendPort.send(jobPort.sendPort);

  // Vòng lặp xử lý job — không bao giờ kết thúc cho đến khi bị kill
  jobPort.listen((dynamic message) {
    if (message is! _InferenceJob) return;
    final job = message;

    try {
      final interpreter = Interpreter.fromAddress(job.interpreterAddress);

      final image = ImageConverter.convertFromRaw(
        planeBytes: job.planeBytes,
        planeRowStrides: job.planeRowStrides,
        planePixelStrides: job.planePixelStrides,
        width: job.imageWidth,
        height: job.imageHeight,
      );

      final input = ImageConverter.imageToFloat32(image, job.inputSize)
          .reshape([1, job.inputSize, job.inputSize, 3]);

      final outShape = interpreter.getOutputTensor(0).shape;
      final output = List.generate(
        outShape[0],
        (_) => List.generate(
          outShape[1],
          (_) => List<double>.filled(outShape[2], 0.0),
        ),
      );

      interpreter.run(input, output);

      final detections = AiHelper.parseYoloV8Output(
        output: output,
        labels: job.labels,
        confidenceThreshold: job.confidenceThreshold,
        iouThreshold: job.iouThreshold,
        maxDetections: job.maxDetections,
      );

      final result = detections
          .map((d) => {
                'label': d.label,
                'confidence': d.confidence,
                'left': d.boundingBox.left,
                'top': d.boundingBox.top,
                'width': d.boundingBox.width,
                'height': d.boundingBox.height,
              })
          .toList();

      job.replyPort.send(result);
    } catch (e) {
      job.replyPort.send('ERROR: $e');
    }
  });
}

// ── Data classes ───────────────────────────────────────────────────────────

class _InferenceJob {
  final SendPort replyPort;
  final List<Uint8List> planeBytes;
  final List<int> planeRowStrides;
  final List<int> planePixelStrides;
  final int imageWidth;
  final int imageHeight;
  final int interpreterAddress;
  final List<String> labels;
  final int inputSize;
  final double confidenceThreshold;
  final double iouThreshold;
  final int maxDetections;

  const _InferenceJob({
    required this.replyPort,
    required this.planeBytes,
    required this.planeRowStrides,
    required this.planePixelStrides,
    required this.imageWidth,
    required this.imageHeight,
    required this.interpreterAddress,
    required this.labels,
    required this.inputSize,
    required this.confidenceThreshold,
    required this.iouThreshold,
    required this.maxDetections,
  });
}
