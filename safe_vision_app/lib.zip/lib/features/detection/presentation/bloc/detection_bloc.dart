import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/usecases/load_model_usecase.dart';
import '../../domain/usecases/detection_object_from_frame.dart';
import '../../../tts/presentation/bloc/tts_bloc.dart';
import '../../../tts/presentation/bloc/tts_event.dart';
import 'detection_event.dart';
import 'detection_state.dart';

class DetectionBloc extends Bloc<DetectionEvent, DetectionState> {
  final LoadModelUsecase _loadModel;
  final DetectionObjectFromFrame _detectFromFrame;
  final TtsBloc _ttsBloc;

  bool _isProcessing = false;

  DateTime _lastSpoken = DateTime.now();

  // lưu object trước đó
  Map<String, double> _previousObjects = {};

  DetectionBloc({
    required LoadModelUsecase loadModel,
    required DetectionObjectFromFrame detectFromFrame,
    required TtsBloc ttsBloc,
  })  : _loadModel = loadModel,
        _detectFromFrame = detectFromFrame,
        _ttsBloc = ttsBloc,
        super(const DetectionInitial()) {
    on<DetectionStarted>(_onStarted);
    on<DetectionStopped>(_onStopped);
    on<DetectionFrameReceived>(_onFrameReceived);
  }
  Future<void> _onStarted(
    DetectionStarted event,
    Emitter<DetectionState> emit,
  ) async {
    emit(const DetectionLoading());
    try {
      await _loadModel.load();

      emit(const DetectionModelReady());
    } catch (e) {
      emit(DetectionFailure(e.toString()));
    }
  }

  void _onStopped(DetectionStopped event, Emitter<DetectionState> emit) {
    _ttsBloc.add(const TtsStop());
    _previousObjects.clear();
    emit(const DetectionInitial());
  }

  Future<void> _onFrameReceived(
    DetectionFrameReceived event,
    Emitter<DetectionState> emit,
  ) async {
    // tránh xử lý chồng
    if (_isProcessing) return;
    _isProcessing = true;

    try {
      final detections = await _detectFromFrame(event.image);

      if (detections.isEmpty) return;

      emit(DetectionSuccess(detections: detections));

      // map object hiện tại: label -> area
      final currentObjects = {
        for (var d in detections) d.label: d.boundingBox.area
      };

      // tìm object mới hoặc lại gần
      final List<dynamic> candidates = [];

      for (var d in detections) {
        final oldArea = _previousObjects[d.label];

        // object mới
        if (oldArea == null) {
          candidates.add(d);
        }
        // object tiến lại gần (area tăng đáng kể)
        else if (d.boundingBox.area > oldArea * 1.3) {
          candidates.add(d);
        }
      }

      // cập nhật lại state
      _previousObjects = currentObjects;

      if (candidates.isEmpty) return;

      // chống spam TTS
      final now = DateTime.now();
      if (now.difference(_lastSpoken).inMilliseconds < 1500) return;
      _lastSpoken = now;

      // ưu tiên object nguy hiểm
      final dangerous = candidates.where((d) => d.isDangerous).toList()
        ..sort((a, b) => b.boundingBox.area.compareTo(a.boundingBox.area));

      if (dangerous.isNotEmpty) {
        final target = dangerous.first;
        _ttsBloc.add(TtsSpeak(
          target.voiceWarning,
          immediate: true,
          withVibration: true,
        ));
      } else {
        final target = candidates.reduce(
          (a, b) => a.confidence > b.confidence ? a : b,
        );
        _ttsBloc.add(TtsSpeak(target.voiceWarning));
      }
    } catch (_) {
      // bỏ qua lỗi frame
    } finally {
      _isProcessing = false;
    }
  }
}
