import '../../features/detection/domain/entities/detection_object.dart';
import '../constants/app_constants.dart';

/// Tiện ích xử lý kết quả đầu ra từ TFLite model
class AiHelper {
  AiHelper._();

  /// Parse output YOLOv8: shape [1, 84, 8400] → List<DetectionObject>
  /// 84 = 4 (box) + 80 (classes COCO)
  static List<DetectionObject> parseYoloV8Output({
    required List<List<List<double>>> output, // [1][84][8400]
    required List<String> labels,
    double confidenceThreshold = AppConstants.confidenceThreshold,
    double iouThreshold        = AppConstants.iouThreshold,
    int    maxDetections       = AppConstants.maxDetections,
  }) {
    final predictions = output[0]; // [84][8400]
    final numBoxes = predictions[0].length; // 8400
    final numClasses = predictions.length - 4;

    final List<_RawBox> rawBoxes = [];

    for (int i = 0; i < numBoxes; i++) {
      // cx, cy, w, h (normalized)
      final cx = predictions[0][i];
      final cy = predictions[1][i];
      final w  = predictions[2][i];
      final h  = predictions[3][i];

      // Tìm class có score cao nhất
      double maxScore = 0;
      int    maxClass = 0;
      for (int c = 0; c < numClasses; c++) {
        final score = predictions[4 + c][i];
        if (score > maxScore) {
          maxScore = score;
          maxClass = c;
        }
      }

      if (maxScore < confidenceThreshold) continue;

      rawBoxes.add(_RawBox(
        left:       cx - w / 2,
        top:        cy - h / 2,
        width:      w,
        height:     h,
        classIndex: maxClass,
        score:      maxScore,
      ));
    }

    // Non-Maximum Suppression
    final nmsResult = _nms(rawBoxes, iouThreshold);

    return nmsResult
        .take(maxDetections)
        .map((b) => DetectionObject(
              label:      b.classIndex < labels.length
                  ? labels[b.classIndex]
                  : 'Object ${b.classIndex}',
              confidence: b.score,
              boundingBox: BoundingBox(
                left:   b.left.clamp(0.0, 1.0),
                top:    b.top.clamp(0.0, 1.0),
                width:  b.width.clamp(0.0, 1.0),
                height: b.height.clamp(0.0, 1.0),
              ),
            ))
        .toList();
  }

  /// Non-Maximum Suppression
  static List<_RawBox> _nms(List<_RawBox> boxes, double iouThreshold) {
    boxes.sort((a, b) => b.score.compareTo(a.score));
    final List<_RawBox> result = [];

    for (final box in boxes) {
      bool suppressed = false;
      for (final kept in result) {
        if (box.classIndex == kept.classIndex &&
            _iou(box, kept) > iouThreshold) {
          suppressed = true;
          break;
        }
      }
      if (!suppressed) result.add(box);
    }
    return result;
  }

  static double _iou(_RawBox a, _RawBox b) {
    final interLeft   = a.left   > b.left   ? a.left   : b.left;
    final interTop    = a.top    > b.top    ? a.top    : b.top;
    final interRight  = (a.left + a.width)  < (b.left + b.width)
        ? (a.left + a.width)  : (b.left + b.width);
    final interBottom = (a.top  + a.height) < (b.top  + b.height)
        ? (a.top  + a.height) : (b.top  + b.height);

    if (interRight <= interLeft || interBottom <= interTop) return 0;

    final interArea = (interRight - interLeft) * (interBottom - interTop);
    final aArea     = a.width * a.height;
    final bArea     = b.width * b.height;
    return interArea / (aArea + bArea - interArea);
  }
}

class _RawBox {
  final double left, top, width, height, score;
  final int classIndex;
  const _RawBox({
    required this.left,
    required this.top,
    required this.width,
    required this.height,
    required this.classIndex,
    required this.score,
  });
}