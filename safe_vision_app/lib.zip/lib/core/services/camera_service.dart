import 'package:camera/camera.dart';
import 'package:flutter/services.dart';
import '../error/exceptions.dart' as ex;

class CameraService {
  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  int _currentIndex = 0;

  CameraController? get controller => _controller;
  bool get isInitialized => _controller?.value.isInitialized ?? false;
  bool get isFrontCamera =>
      _cameras.isNotEmpty &&
      _cameras[_currentIndex].lensDirection == CameraLensDirection.front;

  Future<void> initialize({int cameraIndex = 0}) async {
    if (isInitialized) return;

    _cameras = await availableCameras();
    if (_cameras.isEmpty) {
      throw const ex.CameraException('Không tìm thấy camera');
    }
    _currentIndex = cameraIndex.clamp(0, _cameras.length - 1);
    await _setupController(_cameras[_currentIndex]);
  }

  Future<void> _setupController(CameraDescription camera) async {
    final old = _controller;
    _controller = null;
    if (old != null) {
      try {
        if (old.value.isStreamingImages) await old.stopImageStream();
        await old.dispose();
      } catch (_) {}
    }

    final ctrl = CameraController(
      camera,
      ResolutionPreset.low,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.yuv420,
    );
    await ctrl.initialize();

    // ── Giới hạn FPS ở hardware: 5fps ────────────────────
    // Giảm số buffer camera allocate từ 30/s xuống 5/s
    // Không cần throttle trong callback nữa
    try {
      await ctrl.lockCaptureOrientation();
      // Dùng Android Camera2 API qua method channel
      await _setHardwareFps(ctrl, minFps: 5, maxFps: 5);
    } catch (_) {
      // Fallback: thiết bị không hỗ trợ → vẫn dùng throttle
    }

    _controller = ctrl;
  }

  /// Gửi capture request để set FPS range qua Camera2 API
  static Future<void> _setHardwareFps(
    CameraController ctrl, {
    required int minFps,
    required int maxFps,
  }) async {
    // Flutter camera plugin expose method setFpsRange từ version 0.10.4+
    try {
      await ctrl.setExposureMode(ExposureMode.auto);
      // camera plugin >= 0.10.3 có method này:
      const channel = MethodChannel('plugins.flutter.io/camera_android');
      await channel.invokeMethod('setFpsRange', {
        'cameraId': 0,
        'min': minFps,
        'max': maxFps,
      });
    } catch (_) {
      // Silent fail — không phải thiết bị nào cũng hỗ trợ
    }
  }

  void startImageStream({required void Function(CameraImage) onFrame}) {
    if (_controller == null || !isInitialized) return;
    if (_controller!.value.isStreamingImages) return;

    // Vẫn giữ throttle làm lớp bảo vệ thứ 2
    DateTime lastProcessed = DateTime(0);
    const minIntervalMs = 300;

    _controller!.startImageStream((CameraImage image) {
      final now = DateTime.now();
      if (now.difference(lastProcessed).inMilliseconds < minIntervalMs) return;
      lastProcessed = now;
      onFrame(image);
    });
  }

  Future<void> stopImageStream() async {
    try {
      if (_controller?.value.isStreamingImages ?? false) {
        await _controller!.stopImageStream();
      }
    } catch (_) {}
  }

  Future<void> switchCamera() async {
    if (_cameras.length < 2) return;
    _currentIndex = (_currentIndex + 1) % _cameras.length;
    await _setupController(_cameras[_currentIndex]);
  }

  Future<void> dispose() async {
    await stopImageStream();
    try {
      await _controller?.dispose();
    } catch (_) {}
    _controller = null;
  }
}
